from django.conf import settings
from django.conf.urls.static import static
from django.urls import include, path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("about/", views.about, name="about"),
    path("book/", views.book, name="book"),
    path("reservations/", views.reservations, name="reservations"),
    path("menu/", views.menu, name="menu"),
    path("menu_item/<int:pk>/", views.display_menu_item, name="menu_item"),
    path("bookings/", views.bookings, name="bookings"),
    path("today_reservation/", views.today_reservation, name="today_reservation"),
    path("editbooking/<uuid:bookingId>/", views.edit_booking, name="edit_booking"),
    path("feedback/<uuid:bookingId>/", views.feedback, name="feedback"),
    path("adminlogin/", views.adminlogin, name='adminlogin'),
    path("admintable/", views.admintable, name='admintable'),
    path("admintablesearch/", views.admintablesearch, name='admintablesearch'),
    path("adminhome/", views.adminhome, name='adminhome'),
    path("adminmenu/",views.adminmenu,name="adminmenu")

]
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)