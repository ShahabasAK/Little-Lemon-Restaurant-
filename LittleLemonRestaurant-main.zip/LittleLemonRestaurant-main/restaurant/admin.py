from django.contrib import admin

admin.site.index_title = "Little-Lemon Administration"
# admin.site.index_template = "index.html"

from .models import (AdminLogin, Booking, Category, Feedback, FeedImage, Menu,
                     MenuImage)

admin.site.register(Menu)
admin.site.register(Booking)
admin.site.register(Category)
admin.site.register(Feedback)
admin.site.register(FeedImage)
admin.site.register(MenuImage)
admin.site.register(AdminLogin)
